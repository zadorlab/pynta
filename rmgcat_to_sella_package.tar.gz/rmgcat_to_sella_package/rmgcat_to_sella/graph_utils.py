def node_test(node1, node2):
    return node1['number'] == node2['number']
